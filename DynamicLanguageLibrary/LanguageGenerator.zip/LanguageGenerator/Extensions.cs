﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicLanguageLibrary.Extensions
{
    static class Extensions
    {
        public static bool ToBoolean(this AmbiguousBool value)
        {
            return value == AmbiguousBool.True;
        }
    }
}
