﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicLanguageLibrary
{
    public class PhoneticAlphabet
    {
        #region Properties

        [YAXLib.YAXAttributeForClass]
        public string Name { get; set; }

        public ObservableCollection<ConsonantPhoneme> Consonants { get; set; }
        public ObservableCollection<VowelPhoneme> Vowels { get; set; }

        #endregion

        #region Constructors

        public PhoneticAlphabet(string filename = null)
        {
            this.Consonants = new ObservableCollection<ConsonantPhoneme>();
            this.Vowels = new ObservableCollection<VowelPhoneme>();
            this.Name = String.Empty;

            if (filename != null)
                this.Load(filename);
        }

        #endregion

        #region Public Functions

        public void Save(string filename)
        {
            YAXLib.YAXSerializer serializer = new YAXLib.YAXSerializer(typeof(PhoneticAlphabet));
            try
            {
                serializer.SerializeToFile(this, filename);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void Load(string filename)
        {
            YAXLib.YAXSerializer serializer = new YAXLib.YAXSerializer(typeof(PhoneticAlphabet));
            try
            {
                PhoneticAlphabet pa = serializer.DeserializeFromFile(filename) as PhoneticAlphabet;
                this.Name = pa.Name;
                foreach (ConsonantPhoneme p in pa.Consonants)
                {
                    this.Consonants.Add(p);
                }
                foreach (VowelPhoneme p in pa.Vowels)
                {
                    this.Vowels.Add(p);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion
    }
}
