﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DynamicLanguageLibrary
{
    public class Character
    {
        public string Glyph { get; set; }
        public Phoneme Phoneme { get; set; }

        public Character(string glyph, Phoneme phoneme = null)
        {
            this.Glyph = glyph;
            this.Phoneme = phoneme;
        }
    }
}
